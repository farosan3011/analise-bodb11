// Configuração e inicialização dos gráficos para o site de análise BODB11

// Configurações globais do Chart.js
Chart.defaults.font.family = "'Roboto', 'Segoe UI', sans-serif";
Chart.defaults.font.size = 12;
Chart.defaults.color = '#212529';
Chart.defaults.plugins.tooltip.backgroundColor = 'rgba(33, 37, 41, 0.9)';
Chart.defaults.plugins.tooltip.padding = 10;
Chart.defaults.plugins.tooltip.cornerRadius = 4;
Chart.defaults.plugins.tooltip.titleFont = { weight: 'bold' };
Chart.defaults.plugins.legend.position = 'bottom';
Chart.defaults.plugins.legend.labels.usePointStyle = true;
Chart.defaults.plugins.legend.labels.padding = 15;

// Função para inicializar todos os gráficos
function initCharts() {
    // Gráfico de comparação de Dividend Yield na página inicial
    if (document.getElementById('dyComparisonChart')) {
        new Chart(document.getElementById('dyComparisonChart'), {
            type: 'bar',
            data: dividendYieldData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.raw + '%';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Dividend Yield (%)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    // Gráfico de comparação de P/VP na página de comparativo
    if (document.getElementById('pvpComparisonChart')) {
        new Chart(document.getElementById('pvpComparisonChart'), {
            type: 'bar',
            data: pvpData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'P/VP'
                        }
                    }
                }
            }
        });
    }

    // Gráfico de preço histórico na página de desempenho
    if (document.getElementById('priceHistoryChart')) {
        new Chart(document.getElementById('priceHistoryChart'), {
            type: 'line',
            data: priceHistoryData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': R$ ' + context.raw.toFixed(2);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        title: {
                            display: true,
                            text: 'Preço (R$)'
                        },
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    }

    // Gráfico de dividendos mensais na página de desempenho
    if (document.getElementById('dividendHistoryChart')) {
        new Chart(document.getElementById('dividendHistoryChart'), {
            type: 'bar',
            data: dividendHistoryData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': R$ ' + context.raw.toFixed(2);
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Dividendos (R$)'
                        },
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toFixed(2);
                            }
                        }
                    }
                }
            }
        });
    }

    // Gráfico de rentabilidade por período na página de desempenho
    if (document.getElementById('returnByPeriodChart')) {
        new Chart(document.getElementById('returnByPeriodChart'), {
            type: 'bar',
            data: returnByPeriodData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.raw.toFixed(2) + '%';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        title: {
                            display: true,
                            text: 'Rentabilidade (%)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    // Gráfico de composição da carteira na página de informações básicas
    if (document.getElementById('portfolioCompositionChart')) {
        new Chart(document.getElementById('portfolioCompositionChart'), {
            type: 'doughnut',
            data: portfolioCompositionData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.label + ': ' + context.raw + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    // Gráfico de comparação de indicadores na página de comparativo
    if (document.getElementById('indicatorsComparisonChart')) {
        new Chart(document.getElementById('indicatorsComparisonChart'), {
            type: 'bar',
            data: indicatorsComparisonData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                if (context.dataset.label === 'Dividend Yield (%)') {
                                    return context.dataset.label + ': ' + context.raw.toFixed(2) + '%';
                                } else {
                                    return context.dataset.label + ': ' + context.raw.toFixed(2);
                                }
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Dividend Yield (%)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    },
                    y1: {
                        type: 'linear',
                        display: true,
                        position: 'right',
                        title: {
                            display: true,
                            text: 'P/VP'
                        },
                        grid: {
                            drawOnChartArea: false
                        }
                    }
                }
            }
        });
    }

    // Gráfico de risco vs retorno na página de comparativo
    if (document.getElementById('riskReturnChart')) {
        new Chart(document.getElementById('riskReturnChart'), {
            type: 'bubble',
            data: riskReturnData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return [
                                    context.raw.name,
                                    'Risco: ' + context.raw.x.toFixed(1),
                                    'Retorno: ' + context.raw.y.toFixed(2) + '%'
                                ];
                            }
                        }
                    }
                },
                scales: {
                    x: {
                        title: {
                            display: true,
                            text: 'Risco (Volatilidade)'
                        },
                        min: 4,
                        max: 7
                    },
                    y: {
                        title: {
                            display: true,
                            text: 'Retorno (Dividend Yield %)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }

    // Gráfico de cenário macroeconômico na página de perspectivas
    if (document.getElementById('macroScenarioChart')) {
        new Chart(document.getElementById('macroScenarioChart'), {
            type: 'line',
            data: macroScenarioData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return context.dataset.label + ': ' + context.raw.toFixed(2) + '%';
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        type: 'linear',
                        display: true,
                        position: 'left',
                        title: {
                            display: true,
                            text: 'Taxa (%)'
                        },
                        ticks: {
                            callback: function(value) {
                                return value + '%';
                            }
                        }
                    }
                }
            }
        });
    }
}

// Inicializar os gráficos quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    initCharts();
});
