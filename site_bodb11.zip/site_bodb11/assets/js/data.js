// Dados para os gráficos do site de análise BODB11

// Dados para o gráfico de comparação de Dividend Yield
const dividendYieldData = {
    labels: ['BODB11', 'CPTI11', 'NUIF11', 'SNID11', 'BDIF11', 'OGIN11', 'KDIF11', 'IFRA11'],
    datasets: [{
        label: 'Dividend Yield (%)',
        data: [6.34, 13.48, 12.31, 12.28, 15.94, 16.87, 11.46, 13.01],
        backgroundColor: [
            'rgba(220, 53, 69, 0.7)',  // BODB11 em vermelho para destacar
            'rgba(25, 135, 84, 0.7)',  // CPTI11
            'rgba(25, 135, 84, 0.7)',  // NUIF11
            'rgba(25, 135, 84, 0.7)',  // SNID11
            'rgba(13, 110, 253, 0.7)', // BDIF11
            'rgba(13, 110, 253, 0.7)', // OGIN11
            'rgba(13, 110, 253, 0.7)', // KDIF11
            'rgba(13, 110, 253, 0.7)'  // IFRA11
        ],
        borderColor: [
            'rgb(220, 53, 69)',
            'rgb(25, 135, 84)',
            'rgb(25, 135, 84)',
            'rgb(25, 135, 84)',
            'rgb(13, 110, 253)',
            'rgb(13, 110, 253)',
            'rgb(13, 110, 253)',
            'rgb(13, 110, 253)'
        ],
        borderWidth: 1
    }]
};

// Dados para o gráfico de comparação de P/VP
const pvpData = {
    labels: ['BODB11', 'CPTI11', 'NUIF11', 'SNID11', 'BDIF11', 'OGIN11', 'KDIF11', 'IFRA11'],
    datasets: [{
        label: 'P/VP',
        data: [0.88, 0.88, 0.89, 0.99, 0.92, 0.77, 1.02, 1.01],
        backgroundColor: 'rgba(13, 110, 253, 0.7)',
        borderColor: 'rgb(13, 110, 253)',
        borderWidth: 1
    }]
};

// Dados para o gráfico de preço histórico
const priceHistoryData = {
    labels: ['Abr/24', 'Mai/24', 'Jun/24', 'Jul/24', 'Ago/24', 'Set/24', 'Out/24', 'Nov/24', 'Dez/24', 'Jan/25', 'Fev/25', 'Mar/25', 'Abr/25'],
    datasets: [{
        label: 'Preço (R$)',
        data: [8.12, 8.05, 7.98, 7.85, 7.70, 7.55, 7.40, 7.43, 7.30, 6.94, 6.80, 7.20, 7.40],
        backgroundColor: 'rgba(13, 110, 253, 0.1)',
        borderColor: 'rgb(13, 110, 253)',
        borderWidth: 2,
        tension: 0.1,
        fill: true
    }]
};

// Dados para o gráfico de dividendos mensais
const dividendHistoryData = {
    labels: ['Abr/24', 'Mai/24', 'Jun/24', 'Jul/24', 'Ago/24', 'Set/24', 'Out/24', 'Nov/24', 'Dez/24', 'Jan/25', 'Fev/25', 'Mar/25', 'Abr/25'],
    datasets: [{
        label: 'Dividendos (R$)',
        data: [0.08, 0.08, 0.07, 0.07, 0.07, 0.06, 0.06, 0.06, 0.06, 0.05, 0.01, 0.04, 0.04],
        backgroundColor: 'rgba(25, 135, 84, 0.7)',
        borderColor: 'rgb(25, 135, 84)',
        borderWidth: 1,
        type: 'bar'
    }]
};

// Dados para o gráfico de rentabilidade por período
const returnByPeriodData = {
    labels: ['1 Mês', '3 Meses', '6 Meses', 'YTD', '1 Ano', '2 Anos', 'Desde IPO'],
    datasets: [{
        label: 'BODB11',
        data: [1.37, 10.45, -1.32, 0.14, -8.75, 2.07, -29.25],
        backgroundColor: 'rgba(13, 110, 253, 0.7)',
        borderColor: 'rgb(13, 110, 253)',
        borderWidth: 1
    }, {
        label: 'Média FI-Infra',
        data: [2.15, 8.75, 3.45, 4.25, 5.80, 12.35, -10.50],
        backgroundColor: 'rgba(108, 117, 125, 0.7)',
        borderColor: 'rgb(108, 117, 125)',
        borderWidth: 1
    }]
};

// Dados para o gráfico de composição da carteira
const portfolioCompositionData = {
    labels: [
        'Rodovias', 
        'Portos', 
        'Energia Solar', 
        'Telecomunicações', 
        'Securitização', 
        'Petróleo e Gás'
    ],
    datasets: [{
        label: 'Composição (%)',
        data: [25, 18, 15, 12, 20, 10],
        backgroundColor: [
            'rgba(13, 110, 253, 0.7)',
            'rgba(25, 135, 84, 0.7)',
            'rgba(255, 193, 7, 0.7)',
            'rgba(13, 202, 240, 0.7)',
            'rgba(108, 117, 125, 0.7)',
            'rgba(220, 53, 69, 0.7)'
        ],
        borderColor: [
            'rgb(13, 110, 253)',
            'rgb(25, 135, 84)',
            'rgb(255, 193, 7)',
            'rgb(13, 202, 240)',
            'rgb(108, 117, 125)',
            'rgb(220, 53, 69)'
        ],
        borderWidth: 1
    }]
};

// Dados para o gráfico de comparação de indicadores
const indicatorsComparisonData = {
    labels: ['BODB11', 'CPTI11', 'NUIF11', 'SNID11'],
    datasets: [
        {
            label: 'Dividend Yield (%)',
            data: [6.34, 13.48, 12.31, 12.28],
            backgroundColor: 'rgba(25, 135, 84, 0.7)',
            borderColor: 'rgb(25, 135, 84)',
            borderWidth: 1,
            yAxisID: 'y'
        },
        {
            label: 'P/VP',
            data: [0.88, 0.88, 0.89, 0.99],
            backgroundColor: 'rgba(13, 110, 253, 0.7)',
            borderColor: 'rgb(13, 110, 253)',
            borderWidth: 1,
            yAxisID: 'y1'
        }
    ]
};

// Dados para o gráfico de risco vs retorno
const riskReturnData = {
    datasets: [{
        label: 'FI-Infra',
        data: [
            { x: 4.5, y: 6.34, r: 10, name: 'BODB11' },
            { x: 5.2, y: 13.48, r: 10, name: 'CPTI11' },
            { x: 4.8, y: 12.31, r: 10, name: 'NUIF11' },
            { x: 4.9, y: 12.28, r: 10, name: 'SNID11' },
            { x: 5.5, y: 15.94, r: 10, name: 'BDIF11' },
            { x: 6.2, y: 16.87, r: 10, name: 'OGIN11' },
            { x: 4.7, y: 11.46, r: 10, name: 'KDIF11' },
            { x: 4.8, y: 13.01, r: 10, name: 'IFRA11' }
        ],
        backgroundColor: [
            'rgba(220, 53, 69, 0.7)',  // BODB11
            'rgba(25, 135, 84, 0.7)',  // CPTI11
            'rgba(25, 135, 84, 0.7)',  // NUIF11
            'rgba(25, 135, 84, 0.7)',  // SNID11
            'rgba(13, 110, 253, 0.7)', // BDIF11
            'rgba(13, 110, 253, 0.7)', // OGIN11
            'rgba(13, 110, 253, 0.7)', // KDIF11
            'rgba(13, 110, 253, 0.7)'  // IFRA11
        ],
        borderColor: [
            'rgb(220, 53, 69)',
            'rgb(25, 135, 84)',
            'rgb(25, 135, 84)',
            'rgb(25, 135, 84)',
            'rgb(13, 110, 253)',
            'rgb(13, 110, 253)',
            'rgb(13, 110, 253)',
            'rgb(13, 110, 253)'
        ]
    }]
};

// Dados para o gráfico de cenário macroeconômico
const macroScenarioData = {
    labels: ['Jan/24', 'Fev/24', 'Mar/24', 'Abr/24', 'Mai/24', 'Jun/24', 'Jul/24', 'Ago/24', 'Set/24', 'Out/24', 'Nov/24', 'Dez/24', 'Jan/25', 'Fev/25', 'Mar/25', 'Abr/25'],
    datasets: [
        {
            label: 'SELIC (%)',
            data: [11.75, 11.75, 11.75, 11.75, 11.75, 11.75, 11.75, 12.25, 12.75, 13.25, 13.25, 13.25, 13.25, 13.25, 13.25, 13.25],
            borderColor: 'rgb(220, 53, 69)',
            backgroundColor: 'rgba(220, 53, 69, 0.1)',
            borderWidth: 2,
            tension: 0.1,
            fill: false,
            yAxisID: 'y'
        },
        {
            label: 'IPCA 12m (%)',
            data: [4.51, 4.50, 4.65, 4.75, 4.70, 4.23, 4.50, 4.61, 4.82, 5.05, 5.21, 5.19, 5.35, 5.60, 5.75, 5.80],
            borderColor: 'rgb(255, 193, 7)',
            backgroundColor: 'rgba(255, 193, 7, 0.1)',
            borderWidth: 2,
            tension: 0.1,
            fill: false,
            yAxisID: 'y'
        }
    ]
};
