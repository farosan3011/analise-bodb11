// Funcionalidades interativas adicionais para o site de análise BODB11

document.addEventListener('DOMContentLoaded', function() {
    // Implementar funcionalidade de comparação interativa
    setupComparisonTool();
    
    // Implementar funcionalidade de simulação de investimento
    setupInvestmentSimulator();
    
    // Implementar funcionalidade de filtro de tabelas
    setupTableFilters();
    
    // Implementar funcionalidade de zoom em gráficos
    setupChartZoom();
    
    // Implementar funcionalidade de exportação de dados
    setupDataExport();
});

// Ferramenta de comparação interativa
function setupComparisonTool() {
    const comparisonTool = document.getElementById('comparison-tool');
    if (!comparisonTool) return;
    
    const fundSelectors = comparisonTool.querySelectorAll('.fund-selector');
    const compareButton = comparisonTool.querySelector('.compare-button');
    const comparisonResult = document.getElementById('comparison-result');
    
    if (!fundSelectors.length || !compareButton || !comparisonResult) return;
    
    compareButton.addEventListener('click', function() {
        // Coletar fundos selecionados
        const selectedFunds = [];
        fundSelectors.forEach(selector => {
            const select = selector.querySelector('select');
            if (select && select.value) {
                selectedFunds.push(select.value);
            }
        });
        
        if (selectedFunds.length < 2) {
            alert('Selecione pelo menos dois fundos para comparar');
            return;
        }
        
        // Dados de exemplo para comparação
        const fundsData = {
            'BODB11': { dy: 6.34, pvp: 0.88, liquidity: 1300000, risk: 4.5 },
            'CPTI11': { dy: 13.48, pvp: 0.88, liquidity: 1100000, risk: 5.2 },
            'NUIF11': { dy: 12.31, pvp: 0.89, liquidity: 980000, risk: 4.8 },
            'SNID11': { dy: 12.28, pvp: 0.99, liquidity: 1050000, risk: 4.9 },
            'BDIF11': { dy: 15.94, pvp: 0.92, liquidity: 1500000, risk: 5.5 },
            'OGIN11': { dy: 16.87, pvp: 0.77, liquidity: 950000, risk: 6.2 }
        };
        
        // Gerar HTML para a tabela de comparação
        let comparisonHTML = '<div class="table-responsive mt-3"><table class="table table-hover"><thead><tr><th>Indicador</th>';
        selectedFunds.forEach(fund => {
            comparisonHTML += `<th>${fund}</th>`;
        });
        comparisonHTML += '</tr></thead><tbody>';
        
        // Adicionar linhas para cada indicador
        const indicators = [
            { name: 'Dividend Yield', key: 'dy', format: (val) => val.toFixed(2) + '%' },
            { name: 'P/VP', key: 'pvp', format: (val) => val.toFixed(2) },
            { name: 'Liquidez Diária', key: 'liquidity', format: (val) => 'R$ ' + (val / 1000000).toFixed(2) + 'M' },
            { name: 'Risco (Volatilidade)', key: 'risk', format: (val) => val.toFixed(1) }
        ];
        
        indicators.forEach(indicator => {
            comparisonHTML += `<tr><td>${indicator.name}</td>`;
            selectedFunds.forEach(fund => {
                const value = fundsData[fund][indicator.key];
                let cellClass = '';
                
                // Destacar o melhor valor para cada indicador
                if (indicator.key === 'dy') {
                    const maxDY = Math.max(...selectedFunds.map(f => fundsData[f].dy));
                    cellClass = value === maxDY ? 'text-success fw-bold' : '';
                } else if (indicator.key === 'pvp') {
                    const minPVP = Math.min(...selectedFunds.map(f => fundsData[f].pvp));
                    cellClass = value === minPVP ? 'text-success fw-bold' : '';
                }
                
                comparisonHTML += `<td class="${cellClass}">${indicator.format(value)}</td>`;
            });
            comparisonHTML += '</tr>';
        });
        
        comparisonHTML += '</tbody></table></div>';
        
        // Adicionar gráfico de comparação
        comparisonHTML += '<div class="chart-container mt-4"><canvas id="comparisonDynamicChart"></canvas></div>';
        
        // Exibir resultado
        comparisonResult.innerHTML = comparisonHTML;
        
        // Criar gráfico de comparação
        const ctx = document.getElementById('comparisonDynamicChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Dividend Yield (%)', 'P/VP', 'Risco'],
                datasets: selectedFunds.map((fund, index) => {
                    const colors = [
                        'rgba(13, 110, 253, 0.7)',
                        'rgba(25, 135, 84, 0.7)',
                        'rgba(220, 53, 69, 0.7)',
                        'rgba(255, 193, 7, 0.7)'
                    ];
                    return {
                        label: fund,
                        data: [
                            fundsData[fund].dy,
                            fundsData[fund].pvp,
                            fundsData[fund].risk
                        ],
                        backgroundColor: colors[index % colors.length],
                        borderColor: colors[index % colors.length].replace('0.7', '1'),
                        borderWidth: 1
                    };
                })
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
}

// Simulador de investimento
function setupInvestmentSimulator() {
    const simulator = document.getElementById('investment-simulator');
    if (!simulator) return;
    
    const initialInvestmentInput = simulator.querySelector('#initial-investment');
    const monthlyContributionInput = simulator.querySelector('#monthly-contribution');
    const timeHorizonInput = simulator.querySelector('#time-horizon');
    const fundSelectorInput = simulator.querySelector('#fund-selector');
    const calculateButton = simulator.querySelector('#calculate-button');
    const simulationResult = document.getElementById('simulation-result');
    
    if (!initialInvestmentInput || !monthlyContributionInput || !timeHorizonInput || 
        !fundSelectorInput || !calculateButton || !simulationResult) return;
    
    calculateButton.addEventListener('click', function() {
        const initialInvestment = parseFloat(initialInvestmentInput.value) || 0;
        const monthlyContribution = parseFloat(monthlyContributionInput.value) || 0;
        const timeHorizon = parseInt(timeHorizonInput.value) || 0;
        const selectedFund = fundSelectorInput.value;
        
        if (initialInvestment <= 0 || timeHorizon <= 0) {
            alert('Por favor, preencha todos os campos corretamente');
            return;
        }
        
        // Dados de exemplo para os fundos
        const fundsData = {
            'BODB11': { dy: 6.34 / 100, price: 7.40 },
            'CPTI11': { dy: 13.48 / 100, price: 8.25 },
            'NUIF11': { dy: 12.31 / 100, price: 9.10 },
            'SNID11': { dy: 12.28 / 100, price: 9.50 }
        };
        
        const fundData = fundsData[selectedFund];
        if (!fundData) return;
        
        // Calcular simulação
        let totalInvestment = initialInvestment;
        let totalDividends = 0;
        let totalShares = initialInvestment / fundData.price;
        
        const monthlyData = [];
        
        for (let month = 1; month <= timeHorizon * 12; month++) {
            // Adicionar contribuição mensal
            if (monthlyContribution > 0) {
                const newShares = monthlyContribution / fundData.price;
                totalShares += newShares;
                totalInvestment += monthlyContribution;
            }
            
            // Calcular dividendos mensais
            const monthlyDividend = totalShares * fundData.price * (fundData.dy / 12);
            totalDividends += monthlyDividend;
            
            // Armazenar dados para o gráfico
            if (month % 12 === 0) {
                monthlyData.push({
                    year: month / 12,
                    investment: totalInvestment,
                    dividends: totalDividends,
                    totalValue: totalShares * fundData.price
                });
            }
        }
        
        // Gerar HTML para o resultado
        let resultHTML = `
            <div class="card mt-4">
                <div class="card-header bg-primary text-white">
                    <h5 class="mb-0">Resultado da Simulação - ${selectedFund}</h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="table-responsive">
                                <table class="table table-sm">
                                    <tbody>
                                        <tr>
                                            <th>Investimento Total:</th>
                                            <td>R$ ${totalInvestment.toFixed(2)}</td>
                                        </tr>
                                        <tr>
                                            <th>Dividendos Acumulados:</th>
                                            <td class="text-success">R$ ${totalDividends.toFixed(2)}</td>
                                        </tr>
                                        <tr>
                                            <th>Valor Final:</th>
                                            <td>R$ ${(totalShares * fundData.price).toFixed(2)}</td>
                                        </tr>
                                        <tr>
                                            <th>Retorno Total:</th>
                                            <td class="text-success">R$ ${(totalShares * fundData.price + totalDividends - totalInvestment).toFixed(2)}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="chart-container">
                                <canvas id="simulationChart"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        simulationResult.innerHTML = resultHTML;
        
        // Criar gráfico de simulação
        const ctx = document.getElementById('simulationChart').getContext('2d');
        new Chart(ctx, {
            type: 'bar',
            data: {
                labels: monthlyData.map(d => `Ano ${d.year}`),
                datasets: [
                    {
                        label: 'Investimento',
                        data: monthlyData.map(d => d.investment),
                        backgroundColor: 'rgba(13, 110, 253, 0.7)',
                        borderColor: 'rgb(13, 110, 253)',
                        borderWidth: 1
                    },
                    {
                        label: 'Dividendos',
                        data: monthlyData.map(d => d.dividends),
                        backgroundColor: 'rgba(25, 135, 84, 0.7)',
                        borderColor: 'rgb(25, 135, 84)',
                        borderWidth: 1
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Valor (R$)'
                        }
                    }
                }
            }
        });
    });
}

// Filtros para tabelas
function setupTableFilters() {
    const tableFilters = document.querySelectorAll('.table-filter');
    if (!tableFilters.length) return;
    
    tableFilters.forEach(filter => {
        const input = filter.querySelector('input');
        const targetTableId = filter.getAttribute('data-target');
        const targetTable = document.getElementById(targetTableId);
        
        if (!input || !targetTable) return;
        
        input.addEventListener('keyup', function() {
            const filterValue = input.value.toLowerCase();
            const rows = targetTable.querySelectorAll('tbody tr');
            
            rows.forEach(row => {
                const text = row.textContent.toLowerCase();
                row.style.display = text.includes(filterValue) ? '' : 'none';
            });
        });
    });
}

// Zoom em gráficos
function setupChartZoom() {
    const chartContainers = document.querySelectorAll('.chart-container');
    if (!chartContainers.length) return;
    
    chartContainers.forEach(container => {
        // Adicionar botão de zoom
        const zoomButton = document.createElement('button');
        zoomButton.className = 'btn btn-sm btn-outline-secondary chart-zoom-btn';
        zoomButton.innerHTML = '<i class="fas fa-search-plus"></i>';
        zoomButton.style.position = 'absolute';
        zoomButton.style.top = '10px';
        zoomButton.style.right = '10px';
        zoomButton.style.zIndex = '10';
        container.style.position = 'relative';
        container.appendChild(zoomButton);
        
        zoomButton.addEventListener('click', function() {
            // Criar modal com versão ampliada do gráfico
            const canvas = container.querySelector('canvas');
            if (!canvas) return;
            
            const chartId = canvas.id;
            const chartTitle = container.closest('.card').querySelector('.card-header').textContent.trim();
            
            const modal = document.createElement('div');
            modal.className = 'modal fade';
            modal.id = `modal-${chartId}`;
            modal.setAttribute('tabindex', '-1');
            modal.setAttribute('aria-hidden', 'true');
            
            modal.innerHTML = `
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">${chartTitle}</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                        </div>
                        <div class="modal-body">
                            <div class="chart-container" style="height: 500px;">
                                <canvas id="${chartId}-modal"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            `;
            
            document.body.appendChild(modal);
            
            // Inicializar modal
            const modalElement = new bootstrap.Modal(document.getElementById(`modal-${chartId}`));
            modalElement.show();
            
            // Clonar gráfico para o modal
            const originalChart = Chart.getChart(chartId);
            if (originalChart) {
                const modalCanvas = document.getElementById(`${chartId}-modal`);
                new Chart(modalCanvas, {
                    type: originalChart.config.type,
                    data: JSON.parse(JSON.stringify(originalChart.data)),
                    options: JSON.parse(JSON.stringify(originalChart.options))
                });
            }
            
            // Remover modal quando fechado
            document.getElementById(`modal-${chartId}`).addEventListener('hidden.bs.modal', function() {
                document.body.removeChild(modal);
            });
        });
    });
}

// Exportação de dados
function setupDataExport() {
    const exportButtons = document.querySelectorAll('.export-data');
    if (!exportButtons.length) return;
    
    exportButtons.forEach(button => {
        const targetType = button.getAttribute('data-type');
        const targetId = button.getAttribute('data-target');
        const target = document.getElementById(targetId);
        
        if (!target) return;
        
        button.addEventListener('click', function() {
            if (targetType === 'table') {
                exportTable(target);
            } else if (targetType === 'chart') {
                exportChart(target);
            }
        });
    });
    
    function exportTable(table) {
        const rows = table.querySelectorAll('tr');
        let csv = [];
        
        rows.forEach(row => {
            const cells = row.querySelectorAll('th, td');
            const rowData = [];
            
            cells.forEach(cell => {
                rowData.push('"' + cell.textContent.trim().replace(/"/g, '""') + '"');
            });
            
            csv.push(rowData.join(','));
        });
        
        const csvContent = csv.join('\n');
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', 'dados_bodb11.csv');
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    function exportChart(chartContainer) {
        const canvas = chartContainer.querySelector('canvas');
        if (!canvas) return;
        
        const link = document.createElement('a');
        link.setAttribute('href', canvas.toDataURL('image/png'));
        link.setAttribute('download', 'grafico_bodb11.png');
        link.style.visibility = 'hidden';
        
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
}
