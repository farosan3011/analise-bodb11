// Funcionalidades gerais para o site de análise BODB11

document.addEventListener('DOMContentLoaded', function() {
    // Inicializar tooltips do Bootstrap
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Inicializar popovers do Bootstrap
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Botão flutuante para navegação rápida em mobile
    const floatingNavBtn = document.getElementById('floating-nav-btn');
    const mobileQuickNav = document.getElementById('mobile-quick-nav');
    
    if (floatingNavBtn && mobileQuickNav) {
        floatingNavBtn.addEventListener('click', function() {
            mobileQuickNav.classList.toggle('show');
        });
        
        // Fechar o menu quando clicar fora dele
        document.addEventListener('click', function(event) {
            if (!floatingNavBtn.contains(event.target) && !mobileQuickNav.contains(event.target)) {
                mobileQuickNav.classList.remove('show');
            }
        });
    }

    // Adicionar funcionalidade para alternar entre períodos nos gráficos de desempenho
    const periodButtons = document.querySelectorAll('.period-selector .btn');
    if (periodButtons.length > 0) {
        periodButtons.forEach(button => {
            button.addEventListener('click', function() {
                // Remover classe ativa de todos os botões
                periodButtons.forEach(btn => btn.classList.remove('active'));
                // Adicionar classe ativa ao botão clicado
                this.classList.add('active');
                
                // Aqui você pode adicionar lógica para atualizar o gráfico com base no período selecionado
                // Por exemplo, usando o atributo data-period do botão
                const period = this.getAttribute('data-period');
                updateChartByPeriod(period);
            });
        });
    }

    // Função para atualizar gráfico com base no período selecionado
    function updateChartByPeriod(period) {
        // Esta função seria implementada para atualizar os dados do gráfico
        // com base no período selecionado (1M, 3M, 6M, 1A, etc.)
        console.log('Atualizando gráfico para o período:', period);
        
        // Exemplo de implementação (simulada):
        // 1. Obter a referência ao gráfico
        const chart = Chart.getChart('priceHistoryChart');
        if (!chart) return;
        
        // 2. Definir novos dados com base no período
        let newData;
        switch(period) {
            case '1M':
                newData = priceHistoryData.labels.slice(-2);
                break;
            case '3M':
                newData = priceHistoryData.labels.slice(-4);
                break;
            case '6M':
                newData = priceHistoryData.labels.slice(-7);
                break;
            case '1A':
                newData = priceHistoryData.labels;
                break;
            default:
                newData = priceHistoryData.labels;
        }
        
        // 3. Atualizar o gráfico (simulado)
        // chart.data.labels = newData;
        // chart.data.datasets[0].data = [...]; // Dados correspondentes ao período
        // chart.update();
    }

    // Adicionar funcionalidade para tabelas ordenáveis
    const sortableTables = document.querySelectorAll('.sortable-table');
    if (sortableTables.length > 0) {
        sortableTables.forEach(table => {
            const headers = table.querySelectorAll('th[data-sort]');
            headers.forEach(header => {
                header.addEventListener('click', function() {
                    const sortBy = this.getAttribute('data-sort');
                    const sortOrder = this.classList.contains('sort-asc') ? 'desc' : 'asc';
                    
                    // Remover classes de ordenação de todos os cabeçalhos
                    headers.forEach(h => {
                        h.classList.remove('sort-asc', 'sort-desc');
                    });
                    
                    // Adicionar classe de ordenação ao cabeçalho clicado
                    this.classList.add(`sort-${sortOrder}`);
                    
                    // Ordenar a tabela
                    sortTable(table, sortBy, sortOrder);
                });
            });
        });
    }

    // Função para ordenar tabela
    function sortTable(table, sortBy, sortOrder) {
        const tbody = table.querySelector('tbody');
        const rows = Array.from(tbody.querySelectorAll('tr'));
        
        // Ordenar as linhas
        rows.sort((a, b) => {
            const aValue = a.querySelector(`td[data-${sortBy}]`).getAttribute(`data-${sortBy}`);
            const bValue = b.querySelector(`td[data-${sortBy}]`).getAttribute(`data-${sortBy}`);
            
            // Converter para número se for numérico
            const aNum = parseFloat(aValue);
            const bNum = parseFloat(bValue);
            
            if (!isNaN(aNum) && !isNaN(bNum)) {
                return sortOrder === 'asc' ? aNum - bNum : bNum - aNum;
            } else {
                return sortOrder === 'asc' ? 
                    aValue.localeCompare(bValue) : 
                    bValue.localeCompare(aValue);
            }
        });
        
        // Reordenar as linhas na tabela
        rows.forEach(row => tbody.appendChild(row));
    }

    // Adicionar funcionalidade para alternar entre visualizações de gráfico/tabela
    const viewToggleButtons = document.querySelectorAll('.view-toggle .btn');
    if (viewToggleButtons.length > 0) {
        viewToggleButtons.forEach(button => {
            button.addEventListener('click', function() {
                const viewType = this.getAttribute('data-view');
                const targetId = this.closest('.view-toggle').getAttribute('data-target');
                const targetContainer = document.getElementById(targetId);
                
                // Remover classe ativa de todos os botões
                this.parentElement.querySelectorAll('.btn').forEach(btn => {
                    btn.classList.remove('active');
                });
                
                // Adicionar classe ativa ao botão clicado
                this.classList.add('active');
                
                // Alternar entre visualizações
                if (targetContainer) {
                    const chartView = targetContainer.querySelector('.chart-view');
                    const tableView = targetContainer.querySelector('.table-view');
                    
                    if (viewType === 'chart') {
                        chartView.classList.remove('d-none');
                        tableView.classList.add('d-none');
                    } else {
                        chartView.classList.add('d-none');
                        tableView.classList.remove('d-none');
                    }
                }
            });
        });
    }

    // Adicionar funcionalidade para carrossel de cards em mobile
    const cardCarousels = document.querySelectorAll('.card-carousel');
    if (cardCarousels.length > 0 && window.innerWidth < 768) {
        cardCarousels.forEach(carousel => {
            // Adicionar indicadores de paginação
            const cards = carousel.querySelectorAll('.card');
            const cardCount = cards.length;
            
            if (cardCount > 1) {
                const paginationContainer = document.createElement('div');
                paginationContainer.className = 'carousel-pagination d-flex justify-content-center mt-3';
                
                for (let i = 0; i < cardCount; i++) {
                    const dot = document.createElement('div');
                    dot.className = 'pagination-dot mx-1';
                    dot.style.width = '8px';
                    dot.style.height = '8px';
                    dot.style.borderRadius = '50%';
                    dot.style.backgroundColor = i === 0 ? '#0d6efd' : '#dee2e6';
                    paginationContainer.appendChild(dot);
                }
                
                carousel.parentNode.insertBefore(paginationContainer, carousel.nextSibling);
                
                // Atualizar indicadores ao rolar
                carousel.addEventListener('scroll', function() {
                    const scrollPosition = this.scrollLeft;
                    const cardWidth = cards[0].offsetWidth + 16; // largura + margem
                    const activeIndex = Math.round(scrollPosition / cardWidth);
                    
                    const dots = paginationContainer.querySelectorAll('.pagination-dot');
                    dots.forEach((dot, index) => {
                        dot.style.backgroundColor = index === activeIndex ? '#0d6efd' : '#dee2e6';
                    });
                });
            }
        });
    }

    // Adicionar botões de compartilhamento em redes sociais
    const shareButtons = document.querySelectorAll('.share-button');
    if (shareButtons.length > 0) {
        shareButtons.forEach(button => {
            button.addEventListener('click', function(e) {
                e.preventDefault();
                const platform = this.getAttribute('data-platform');
                const url = encodeURIComponent(window.location.href);
                const title = encodeURIComponent(document.title);
                
                let shareUrl;
                switch(platform) {
                    case 'twitter':
                        shareUrl = `https://twitter.com/intent/tweet?url=${url}&text=${title}`;
                        break;
                    case 'facebook':
                        shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}`;
                        break;
                    case 'linkedin':
                        shareUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${url}`;
                        break;
                    case 'whatsapp':
                        shareUrl = `https://api.whatsapp.com/send?text=${title}%20${url}`;
                        break;
                    case 'telegram':
                        shareUrl = `https://t.me/share/url?url=${url}&text=${title}`;
                        break;
                }
                
                if (shareUrl) {
                    window.open(shareUrl, '_blank', 'width=600,height=400');
                }
            });
        });
    }
});
